"""SQLite registry and migration engine for Module 2.

This module provides a transaction-safe system-of-record for ingest state,
acceptance history, and immutable audit logging.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

LATEST_SCHEMA_VERSION = 2
ALLOWED_FILE_STATUSES = {"pending", "accepted", "rejected", "purged"}


class RegistryError(RuntimeError):
    """Raised when registry operations fail."""


@dataclass(frozen=True)
class FileRecord:
    """Typed view over one row in the files table."""

    sha256: str
    size_bytes: int
    status: str
    original_filename: str | None
    current_path: str | None
    first_seen_at: str
    updated_at: str


@dataclass(frozen=True)
class AuditRecord:
    """Typed view over one row in the audit log."""

    id: int
    sha256: str | None
    account_name: str | None
    action: str
    reason: str | None
    details_json: str | None
    actor: str
    ts: str


@dataclass(frozen=True)
class LivePhotoPairRecord:
    """Typed view over one row in the live_photo_pairs table."""

    pair_id: str
    account: str
    stem: str
    photo_sha256: str
    video_sha256: str
    status: str
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class AcceptContext:
    """Authoritative metadata required for pending->accepted transitions."""

    account: str
    source_path: str
    modified_time: str


class Registry:
    """High-level API for schema migration and state transitions."""

    def __init__(self, db_path: Path | str) -> None:
        self._db_path = Path(db_path)

    @property
    def db_path(self) -> Path:
        """Expose the resolved database path."""

        return self._db_path

    def initialize(self) -> None:
        """Create parent directories, initialize schema, and run migrations."""

        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            _set_pragmas(conn)
            _run_migrations(conn)
            _ensure_optional_tables(conn)

    def backup_to(self, destination: Path | str) -> Path:
        """Create a SQLite-consistent backup of the registry database."""

        destination_path = Path(destination)
        destination_path.parent.mkdir(parents=True, exist_ok=True)

        with self._connect() as source_conn:
            _set_pragmas(source_conn)
            with sqlite3.connect(destination_path) as backup_conn:
                source_conn.backup(backup_conn)

        return destination_path

    def prune_auth_failure_audit_backlog(self, *, keep_latest: int = 0) -> int:
        """Prune historical auth_failure rows while preserving append-only guarantees during normal operation."""

        if keep_latest < 0:
            raise RegistryError("keep_latest must be >= 0")

        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")

            total_auth_failures = int(
                conn.execute(
                    "SELECT COUNT(*) FROM audit_log WHERE action = 'auth_failure'",
                ).fetchone()[0]
            )
            prune_count = max(0, total_auth_failures - keep_latest)
            if prune_count == 0:
                conn.commit()
                return 0

            retained_clause = ""
            retained_params: tuple[object, ...] = ("auth_failure",)
            if keep_latest > 0:
                retained_clause = (
                    " OR id IN ("
                    "SELECT id FROM audit_log WHERE action = ? ORDER BY id DESC LIMIT ?"
                    ")"
                )
                retained_params = ("auth_failure", "auth_failure", keep_latest)

            conn.execute(
                """
                CREATE TABLE audit_log_rebuilt (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sha256 TEXT,
                    account_name TEXT,
                    action TEXT NOT NULL,
                    reason TEXT,
                    details_json TEXT,
                    actor TEXT NOT NULL,
                    ts TEXT NOT NULL
                )
                """
            )
            conn.execute(
                f"""
                INSERT INTO audit_log_rebuilt (id, sha256, account_name, action, reason, details_json, actor, ts)
                SELECT id, sha256, account_name, action, reason, details_json, actor, ts
                FROM audit_log
                WHERE action != ?{retained_clause}
                ORDER BY id ASC
                """,
                retained_params,
            )
            conn.execute("DROP TRIGGER IF EXISTS trg_audit_log_no_update")
            conn.execute("DROP TRIGGER IF EXISTS trg_audit_log_no_delete")
            conn.execute("DROP TABLE audit_log")
            conn.execute("ALTER TABLE audit_log_rebuilt RENAME TO audit_log")
            _ensure_audit_log_triggers(conn)
            conn.commit()

        return prune_count

    def create_or_update_file(
        self,
        *,
        sha256: str,
        size_bytes: int,
        status: str,
        original_filename: str | None = None,
        current_path: str | None = None,
    ) -> None:
        """Insert or update a file record while preserving original timestamps."""

        self._validate_status(status)
        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO files (
                    sha256,
                    size_bytes,
                    status,
                    original_filename,
                    current_path,
                    first_seen_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(sha256) DO UPDATE SET
                    size_bytes = excluded.size_bytes,
                    status = excluded.status,
                    original_filename = COALESCE(excluded.original_filename, files.original_filename),
                    current_path = excluded.current_path,
                    updated_at = excluded.updated_at
                """,
                (sha256, size_bytes, status, original_filename, current_path, now, now),
            )
            conn.commit()

    def upsert_metadata_index(
        self,
        *,
        account: str,
        onedrive_id: str,
        size_bytes: int,
        modified_time: str,
        sha256: str,
    ) -> None:
        """Insert or update metadata pre-filter index entries."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO metadata_index (
                    account_name,
                    onedrive_id,
                    size_bytes,
                    modified_time,
                    sha256,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(account_name, onedrive_id) DO UPDATE SET
                    size_bytes = excluded.size_bytes,
                    modified_time = excluded.modified_time,
                    sha256 = excluded.sha256,
                    updated_at = excluded.updated_at
                """,
                (account, onedrive_id, size_bytes, modified_time, sha256, now, now),
            )
            conn.commit()

    def upsert_file_origin(
        self,
        *,
        sha256: str,
        account: str,
        onedrive_id: str,
        path_hint: str | None,
    ) -> None:
        """Track account-to-file provenance for auditability."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO file_origins (
                    account,
                    onedrive_id,
                    sha256,
                    path_hint,
                    first_seen_at,
                    last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(account, onedrive_id) DO UPDATE SET
                    sha256 = excluded.sha256,
                    path_hint = excluded.path_hint,
                    last_seen_at = excluded.last_seen_at
                """,
                (account, onedrive_id, sha256, path_hint, now, now),
            )
            conn.commit()

    def record_acceptance(self, *, sha256: str, account: str, source_path: str) -> None:
        """Append immutable acceptance history for explicit accept transitions."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO accepted_records (
                    sha256,
                    account,
                    source_path,
                    accepted_at
                ) VALUES (?, ?, ?, ?)
                """,
                (sha256, account, source_path, now),
            )
            conn.commit()

    def finalize_unknown_ingest(
        self,
        *,
        sha256: str,
        size_bytes: int,
        original_filename: str,
        current_path: str,
        account: str,
        onedrive_id: str,
        source_path: str,
        modified_time: str,
        actor: str,
        fail_after_step: int | None = None,
    ) -> None:
        """Persist unknown-hash ingest state in one atomic transaction.

        Files land in 'pending' status awaiting human review. This updates
        files, metadata_index, file_origins, and audit_log as one unit.
        """

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")

            step = 1
            conn.execute(
                """
                INSERT INTO files (
                    sha256,
                    size_bytes,
                    status,
                    original_filename,
                    current_path,
                    first_seen_at,
                    updated_at
                ) VALUES (?, ?, 'pending', ?, ?, ?, ?)
                ON CONFLICT(sha256) DO UPDATE SET
                    size_bytes = excluded.size_bytes,
                    status = 'pending',
                    original_filename = COALESCE(excluded.original_filename, files.original_filename),
                    current_path = excluded.current_path,
                    updated_at = excluded.updated_at
                """,
                (sha256, size_bytes, original_filename, current_path, now, now),
            )
            if fail_after_step == step:
                conn.rollback()
                raise RegistryError("Injected failure after files write")

            step = 2
            conn.execute(
                """
                INSERT INTO metadata_index (
                    account_name,
                    onedrive_id,
                    size_bytes,
                    modified_time,
                    sha256,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(account_name, onedrive_id) DO UPDATE SET
                    size_bytes = excluded.size_bytes,
                    modified_time = excluded.modified_time,
                    sha256 = excluded.sha256,
                    updated_at = excluded.updated_at
                """,
                (account, onedrive_id, size_bytes, modified_time, sha256, now, now),
            )
            if fail_after_step == step:
                conn.rollback()
                raise RegistryError("Injected failure after metadata_index write")

            step = 3
            conn.execute(
                """
                INSERT INTO file_origins (
                    account,
                    onedrive_id,
                    sha256,
                    path_hint,
                    first_seen_at,
                    last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(account, onedrive_id) DO UPDATE SET
                    sha256 = excluded.sha256,
                    path_hint = excluded.path_hint,
                    last_seen_at = excluded.last_seen_at
                """,
                (account, onedrive_id, sha256, source_path, now, now),
            )
            if fail_after_step == step:
                conn.rollback()
                raise RegistryError("Injected failure after file_origins write")

            step = 4
            conn.execute(
                """
                INSERT INTO audit_log (sha256, account_name, action, reason, details_json, actor, ts)
                VALUES (?, ?, 'pending', 'unknown_hash', NULL, ?, ?)
                """,
                (sha256, account, actor, now),
            )
            if fail_after_step == step:
                conn.rollback()
                raise RegistryError("Injected failure after audit_log write")

            conn.commit()

    def finalize_accept_from_pending(
        self,
        *,
        sha256: str,
        new_path: str,
        account: str,
        source_path: str,
        actor: str,
        reason: str = "operator_accept",
    ) -> None:
        """Persist operator acceptance of a pending file in one atomic transaction.

        Transitions pending→accepted, writes to accepted_records, updates
        current_path, and appends an audit event.
        """

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute("SELECT status FROM files WHERE sha256 = ?", (sha256,))
            row = cursor.fetchone()
            if row is None:
                conn.rollback()
                raise RegistryError(f"Cannot accept missing sha256: {sha256}")
            if row["status"] != "pending":
                conn.rollback()
                raise RegistryError(
                    f"Cannot accept file with status '{row['status']}': expected 'pending'"
                )

            conn.execute(
                "UPDATE files SET status = 'accepted', current_path = ?, updated_at = ? WHERE sha256 = ?",
                (new_path, now, sha256),
            )
            conn.execute(
                """
                INSERT INTO accepted_records (sha256, account, source_path, accepted_at)
                VALUES (?, ?, ?, ?)
                """,
                (sha256, account, source_path, now),
            )
            conn.execute(
                """
                INSERT INTO audit_log (sha256, account_name, action, reason, details_json, actor, ts)
                VALUES (?, ?, 'accepted', ?, NULL, ?, ?)
                """,
                (sha256, account, reason, actor, now),
            )
            conn.commit()

    def get_accept_context(self, *, sha256: str) -> AcceptContext | None:
        """Return latest account/source path and modified_time for pending accept."""

        with self._connect() as conn:
            _set_pragmas(conn)
            row = conn.execute(
                """
                SELECT
                    o.account AS account,
                    COALESCE(o.path_hint, '/') AS source_path,
                    m.modified_time AS modified_time
                FROM file_origins AS o
                LEFT JOIN metadata_index AS m
                  ON m.account_name = o.account
                 AND m.onedrive_id = o.onedrive_id
                 AND m.sha256 = o.sha256
                WHERE o.sha256 = ?
                ORDER BY o.last_seen_at DESC
                LIMIT 1
                """,
                (sha256,),
            ).fetchone()

        if row is None:
            return None

        modified_time = row["modified_time"] or _utc_now()
        return AcceptContext(
            account=str(row["account"]),
            source_path=str(row["source_path"]),
            modified_time=str(modified_time),
        )

    def finalize_known_ingest(
        self,
        *,
        sha256: str,
        known_status: str,
        account: str,
        onedrive_id: str,
        source_path: str,
        modified_time: str,
        size_bytes: int,
        actor: str,
    ) -> None:
        """Persist known-hash ingest side effects in one atomic transaction."""

        if known_status not in ALLOWED_FILE_STATUSES:
            raise RegistryError(f"Invalid known status: {known_status}")

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO metadata_index (
                    account_name,
                    onedrive_id,
                    size_bytes,
                    modified_time,
                    sha256,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(account_name, onedrive_id) DO UPDATE SET
                    size_bytes = excluded.size_bytes,
                    modified_time = excluded.modified_time,
                    sha256 = excluded.sha256,
                    updated_at = excluded.updated_at
                """,
                (account, onedrive_id, size_bytes, modified_time, sha256, now, now),
            )
            conn.execute(
                """
                INSERT INTO file_origins (
                    account,
                    onedrive_id,
                    sha256,
                    path_hint,
                    first_seen_at,
                    last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(account, onedrive_id) DO UPDATE SET
                    sha256 = excluded.sha256,
                    path_hint = excluded.path_hint,
                    last_seen_at = excluded.last_seen_at
                """,
                (account, onedrive_id, sha256, source_path, now, now),
            )
            conn.execute(
                """
                INSERT INTO audit_log (sha256, account_name, action, reason, details_json, actor, ts)
                VALUES (?, ?, ?, 'known_hash', NULL, ?, ?)
                """,
                (sha256, account, f"discard_{known_status}", actor, now),
            )
            conn.commit()

    def clear_current_path(self, *, sha256: str) -> None:
        """Clear current_path when operators manually move files out of queue."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                "UPDATE files SET current_path = NULL, updated_at = ? WHERE sha256 = ?",
                (now, sha256),
            )
            conn.commit()

    def update_current_path(self, *, sha256: str, new_path: str) -> None:
        """Update the stored current_path after an operator moves a file."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                "UPDATE files SET current_path = ?, updated_at = ? WHERE sha256 = ?",
                (new_path, now, sha256),
            )
            conn.commit()

    def finalize_purge_from_rejected(
        self,
        *,
        sha256: str,
        reason: str,
        actor: str,
    ) -> None:
        """Atomically transition rejected→purged and clear current_path.

        Raises RegistryError when the record is missing or not in rejected state.
        """

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute(
                "SELECT status FROM files WHERE sha256 = ?", (sha256,)
            )
            row = cursor.fetchone()
            if row is None:
                conn.rollback()
                raise RegistryError(f"Cannot purge missing sha256: {sha256}")
            if row[0] != "rejected":
                conn.rollback()
                raise RegistryError(
                    f"Cannot purge sha256 with status '{row[0]}': expected 'rejected'"
                )
            conn.execute(
                "UPDATE files SET status = 'purged', current_path = NULL, updated_at = ? WHERE sha256 = ?",
                (now, sha256),
            )
            conn.execute(
                """
                INSERT INTO audit_log (sha256, account_name, action, reason, details_json, actor, ts)
                VALUES (?, NULL, 'purged', ?, NULL, ?, ?)
                """,
                (sha256, reason, actor, now),
            )
            conn.commit()

    def transition_status(
        self,
        *,
        sha256: str,
        new_status: str,
        reason: str,
        actor: str,
    ) -> None:
        """Transition status atomically and append immutable audit event."""

        self._validate_status(new_status)
        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute("SELECT sha256 FROM files WHERE sha256 = ?", (sha256,))
            if cursor.fetchone() is None:
                conn.rollback()
                raise RegistryError(f"Cannot transition missing sha256: {sha256}")

            conn.execute(
                "UPDATE files SET status = ?, updated_at = ? WHERE sha256 = ?",
                (new_status, now, sha256),
            )
            conn.execute(
                """
                INSERT INTO audit_log (sha256, account_name, action, reason, details_json, actor, ts)
                VALUES (?, NULL, ?, ?, NULL, ?, ?)
                """,
                (sha256, new_status, reason, actor, now),
            )
            conn.commit()

    def append_audit_event(
        self,
        *,
        sha256: str | None,
        action: str,
        reason: str | None,
        actor: str,
        account_name: str | None = None,
        details_json: str | None = None,
    ) -> int:
        """Append one immutable event row and return its primary key."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute(
                """
                INSERT INTO audit_log (sha256, account_name, action, reason, details_json, actor, ts)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (sha256, account_name, action, reason, details_json, actor, now),
            )
            conn.commit()
            return int(cursor.lastrowid)

    def append_ingest_terminal_event(
        self,
        *,
        batch_run_id: str,
        sequence_no: int,
        account: str,
        onedrive_id: str,
        sha256: str | None,
        action: str,
        reason: str | None,
        actor: str,
    ) -> int:
        """Append terminal ingest event with batch and sequence metadata."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute(
                """
                INSERT INTO ingest_terminal_audit (
                    batch_run_id,
                    sequence_no,
                    account,
                    onedrive_id,
                    sha256,
                    action,
                    reason,
                    actor,
                    ts
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    batch_run_id,
                    sequence_no,
                    account,
                    onedrive_id,
                    sha256,
                    action,
                    reason,
                    actor,
                    now,
                ),
            )
            conn.commit()
            return int(cursor.lastrowid)

    def get_file(self, *, sha256: str) -> FileRecord | None:
        """Return one file row by SHA-256 or None when missing."""

        with self._connect() as conn:
            _set_pragmas(conn)
            row = conn.execute(
                """
                SELECT sha256, size_bytes, status, original_filename, current_path, first_seen_at, updated_at
                FROM files
                WHERE sha256 = ?
                """,
                (sha256,),
            ).fetchone()

        if row is None:
            return None
        return FileRecord(
            sha256=row["sha256"],
            size_bytes=row["size_bytes"],
            status=row["status"],
            original_filename=row["original_filename"],
            current_path=row["current_path"],
            first_seen_at=row["first_seen_at"],
            updated_at=row["updated_at"],
        )

    def list_audit_events(self, *, sha256: str) -> list[AuditRecord]:
        """Return immutable audit rows for one SHA-256 ordered by insertion."""

        with self._connect() as conn:
            _set_pragmas(conn)
            rows = conn.execute(
                """
                SELECT id, sha256, account_name, action, reason, details_json, actor, ts
                FROM audit_log
                WHERE sha256 = ?
                ORDER BY id ASC
                """,
                (sha256,),
            ).fetchall()

        return [
            AuditRecord(
                id=row["id"],
                sha256=row["sha256"],
                account_name=row["account_name"],
                action=row["action"],
                reason=row["reason"],
                details_json=row["details_json"],
                actor=row["actor"],
                ts=row["ts"],
            )
            for row in rows
        ]

    def upsert_external_hash_cache(
        self,
        *,
        account_name: str,
        source_relpath: str,
        hash_algo: str,
        hash_value: str,
        verified_sha256: str | None = None,
    ) -> None:
        """Insert or update external hash cache rows used by sync-import mode."""

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO external_hash_cache (
                    account_name,
                    source_relpath,
                    hash_algo,
                    hash_value,
                    verified_sha256,
                    first_seen_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(account_name, source_relpath, hash_algo, hash_value) DO UPDATE SET
                    verified_sha256 = COALESCE(excluded.verified_sha256, external_hash_cache.verified_sha256),
                    updated_at = excluded.updated_at
                """,
                (account_name, source_relpath, hash_algo, hash_value, verified_sha256, now, now),
            )
            conn.commit()

    def acceptance_count(self, *, sha256: str) -> int:
        """Return number of acceptance history entries for one SHA-256."""

        with self._connect() as conn:
            _set_pragmas(conn)
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM accepted_records WHERE sha256 = ?",
                (sha256,),
            ).fetchone()
        return int(row["n"]) if row is not None else 0

    def upsert_live_photo_pair(
        self,
        *,
        pair_id: str,
        account: str,
        stem: str,
        photo_sha256: str,
        video_sha256: str,
        status: str = "paired",
    ) -> None:
        """Insert or update a live photo pair mapping."""

        if status not in {"paired", "pending", "accepted", "rejected", "purged"}:
            raise RegistryError(f"Invalid live photo pair status: {status}")

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO live_photo_pairs (
                    pair_id,
                    account,
                    stem,
                    photo_sha256,
                    video_sha256,
                    status,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(pair_id) DO UPDATE SET
                    account = excluded.account,
                    stem = excluded.stem,
                    photo_sha256 = excluded.photo_sha256,
                    video_sha256 = excluded.video_sha256,
                    status = excluded.status,
                    updated_at = excluded.updated_at
                """,
                (
                    pair_id,
                    account,
                    stem,
                    photo_sha256,
                    video_sha256,
                    status,
                    now,
                    now,
                ),
            )
            conn.commit()

    def get_live_photo_pair(self, *, pair_id: str) -> LivePhotoPairRecord | None:
        """Return one live photo pair row or None when missing."""

        with self._connect() as conn:
            _set_pragmas(conn)
            row = conn.execute(
                """
                SELECT pair_id, account, stem, photo_sha256, video_sha256, status, created_at, updated_at
                FROM live_photo_pairs
                WHERE pair_id = ?
                """,
                (pair_id,),
            ).fetchone()

        if row is None:
            return None
        return LivePhotoPairRecord(
            pair_id=row["pair_id"],
            account=row["account"],
            stem=row["stem"],
            photo_sha256=row["photo_sha256"],
            video_sha256=row["video_sha256"],
            status=row["status"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def get_live_photo_pair_for_member(self, *, sha256: str) -> LivePhotoPairRecord | None:
        """Return pair containing given member SHA or None when not paired."""

        with self._connect() as conn:
            _set_pragmas(conn)
            row = conn.execute(
                """
                SELECT pair_id, account, stem, photo_sha256, video_sha256, status, created_at, updated_at
                FROM live_photo_pairs
                WHERE photo_sha256 = ? OR video_sha256 = ?
                LIMIT 1
                """,
                (sha256, sha256),
            ).fetchone()

        if row is None:
            return None
        return LivePhotoPairRecord(
            pair_id=row["pair_id"],
            account=row["account"],
            stem=row["stem"],
            photo_sha256=row["photo_sha256"],
            video_sha256=row["video_sha256"],
            status=row["status"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def apply_live_photo_pair_status(
        self,
        *,
        pair_id: str,
        new_status: str,
        reason: str,
        actor: str,
    ) -> None:
        """Apply one status transition consistently to both pair members."""

        if new_status not in {"pending", "accepted", "rejected", "purged"}:
            raise RegistryError(
                f"Invalid live photo propagated status: {new_status}"
            )

        pair = self.get_live_photo_pair(pair_id=pair_id)
        if pair is None:
            raise RegistryError(f"Missing live photo pair: {pair_id}")

        self.transition_status(
            sha256=pair.photo_sha256,
            new_status=new_status,
            reason=reason,
            actor=actor,
        )
        self.transition_status(
            sha256=pair.video_sha256,
            new_status=new_status,
            reason=reason,
            actor=actor,
        )

        now = _utc_now()
        with self._connect() as conn:
            _set_pragmas(conn)
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                UPDATE live_photo_pairs
                SET status = ?, updated_at = ?
                WHERE pair_id = ?
                """,
                (new_status, now, pair_id),
            )
            conn.commit()

    def schema_version(self) -> int:
        """Return current SQLite user_version schema integer."""

        with self._connect() as conn:
            _set_pragmas(conn)
            row = conn.execute("PRAGMA user_version").fetchone()
        return int(row[0]) if row is not None else 0

    def _connect(self) -> sqlite3.Connection:
        """Open a SQLite connection with row access by column names."""

        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def _validate_status(value: str) -> None:
        """Reject unknown status values early to keep state clean."""

        if value not in ALLOWED_FILE_STATUSES:
            raise RegistryError(
                f"Invalid status '{value}', expected one of {sorted(ALLOWED_FILE_STATUSES)}"
            )


def _set_pragmas(conn: sqlite3.Connection) -> None:
    """Set connection-level SQLite pragmas used by registry operations."""

    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")


def _run_migrations(conn: sqlite3.Connection) -> None:
    """Initialize or reject registry schemas for the v2-only runtime."""

    row = conn.execute("PRAGMA user_version").fetchone()
    current = int(row[0]) if row is not None else 0

    if current > LATEST_SCHEMA_VERSION:
        raise RegistryError(
            f"Database schema version {current} is newer than supported {LATEST_SCHEMA_VERSION}"
        )

    if current == 0:
        conn.executescript(_schema_v2_sql())
        conn.execute(f"PRAGMA user_version = {LATEST_SCHEMA_VERSION}")
        conn.commit()
        return

    if current != LATEST_SCHEMA_VERSION:
        raise RegistryError(
            "Legacy registry schema detected. v2.0 requires a freshly bootstrapped "
            f"registry.db at schema {LATEST_SCHEMA_VERSION}; found schema {current}."
        )


def _ensure_optional_tables(conn: sqlite3.Connection) -> None:
    """Create additive optional tables used by newer runtime features."""

    conn.executescript(
        """
CREATE TABLE IF NOT EXISTS ingest_terminal_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_run_id TEXT NOT NULL,
    sequence_no INTEGER NOT NULL,
    account TEXT NOT NULL,
    onedrive_id TEXT NOT NULL,
    sha256 TEXT,
    action TEXT NOT NULL,
    reason TEXT,
    actor TEXT NOT NULL,
    ts TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS blocked_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern TEXT NOT NULL UNIQUE,
    rule_type TEXT NOT NULL CHECK (rule_type IN ('filename', 'regex')),
    reason TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ui_action_idempotency (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    idempotency_key TEXT NOT NULL UNIQUE,
    action TEXT NOT NULL,
    item_id TEXT NOT NULL,
    request_body_json TEXT,
    response_status INTEGER NOT NULL,
    response_body_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);
        """
    )
    conn.commit()


def _schema_v2_sql() -> str:
    """Return SQL script for a fresh v2 registry bootstrap."""

    return """
CREATE TABLE IF NOT EXISTS files (
    sha256 TEXT PRIMARY KEY,
    size_bytes INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'accepted', 'rejected', 'purged')),
    original_filename TEXT,
    current_path TEXT,
    first_seen_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS metadata_index (
    account_name TEXT NOT NULL,
    onedrive_id TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    modified_time TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (account_name, onedrive_id)
);

CREATE TABLE IF NOT EXISTS accepted_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sha256 TEXT NOT NULL,
    account TEXT NOT NULL,
    source_path TEXT NOT NULL,
    accepted_at TEXT NOT NULL,
    FOREIGN KEY (sha256) REFERENCES files(sha256)
);

CREATE TABLE IF NOT EXISTS file_origins (
    account TEXT NOT NULL,
    onedrive_id TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    path_hint TEXT,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    PRIMARY KEY (account, onedrive_id),
    FOREIGN KEY (sha256) REFERENCES files(sha256)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sha256 TEXT,
    account_name TEXT,
    action TEXT NOT NULL,
    reason TEXT,
    details_json TEXT,
    actor TEXT NOT NULL,
    ts TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS live_photo_pairs (
    pair_id TEXT PRIMARY KEY,
    account TEXT NOT NULL,
    stem TEXT NOT NULL,
    photo_sha256 TEXT NOT NULL,
    video_sha256 TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('paired', 'pending', 'accepted', 'rejected', 'purged')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (photo_sha256) REFERENCES files(sha256),
    FOREIGN KEY (video_sha256) REFERENCES files(sha256)
);

CREATE TABLE IF NOT EXISTS external_hash_cache (
    account_name TEXT NOT NULL,
    source_relpath TEXT NOT NULL,
    hash_algo TEXT NOT NULL,
    hash_value TEXT NOT NULL,
    verified_sha256 TEXT,
    first_seen_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (account_name, source_relpath, hash_algo, hash_value)
);

CREATE TRIGGER IF NOT EXISTS trg_audit_log_no_update
BEFORE UPDATE ON audit_log
BEGIN
    SELECT RAISE(FAIL, 'audit_log is append-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_audit_log_no_delete
BEFORE DELETE ON audit_log
BEGIN
    SELECT RAISE(FAIL, 'audit_log is append-only');
END;
"""


def _ensure_audit_log_triggers(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TRIGGER IF NOT EXISTS trg_audit_log_no_update
        BEFORE UPDATE ON audit_log
        BEGIN
            SELECT RAISE(FAIL, 'audit_log is append-only');
        END;

        CREATE TRIGGER IF NOT EXISTS trg_audit_log_no_delete
        BEFORE DELETE ON audit_log
        BEGIN
            SELECT RAISE(FAIL, 'audit_log is append-only');
        END;
        """
    )


def _utc_now() -> str:
    """Return UTC timestamp in ISO-8601 format with timezone suffix."""

    return datetime.now(UTC).isoformat()
